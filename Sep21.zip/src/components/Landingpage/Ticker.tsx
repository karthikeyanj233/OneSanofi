import { useTranslation } from "react-i18next";
import "./Ticker.css";
const Ticker = () => {
  const[t,i18n]=useTranslation('global');
  return (
    <>
<div className="ticker-wrap">     
<div className="ticker">
<div className="ticker_item">{t("Landing_Page.ticker")}</div>
</div>
</div>
</>
  )

}




export default Ticker