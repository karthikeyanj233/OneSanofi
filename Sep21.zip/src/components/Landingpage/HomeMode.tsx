export interface DashboardList{
    id:Number 
    name:String 
    code:String 
}
export interface Datamodel{
    heading:String 
    List:DashboardList[] 
}
