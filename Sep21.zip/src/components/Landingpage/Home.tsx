import { useEffect, useState } from 'react';
import './Home.css';
import { Grid,  List, ListItem } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Navebar from '../Reusable/Navebar/Navebar';
import axios from 'axios';
import Ticker from './Ticker';
import { Box } from '@material-ui/core';
import {Datamodel} from './HomeMode'
import {API} from '../../config'
import Loader from '../Reusable/Form/Loader/Loader';
import Footer from '../Reusable/Footer/Footer';
import { useTranslation } from 'react-i18next';
export default function Home() {
const[loading,setLoading]=useState(Boolean)
const [modelone, setModelone] = useState([] as Datamodel[] | any);
const [modeltwo, setModeltwo] = useState([] as Datamodel[] | any );
const [modelthree, setModelthree] = useState([] as Datamodel[] | any);
const [modelfour, setModelfour] = useState([] as Datamodel[] | any);
const [modelfive, setModelfive] = useState([] as Datamodel[] | any);
const [modelsix, setModelsix] = useState([] as Datamodel[] | any);
const [readMore1, setReadMore1] = useState(true);
const [readMore2, setReadMore2] = useState(true);
const [readMore3, setReadMore3] = useState(false);
const [readMore4, setReadMore4] = useState(true);
const [readMore5, setReadMore5] = useState(true);
const [readMore6, setReadMore6] = useState(true);
const token =localStorage.getItem("Token") as any
const[t,i18n]=useTranslation('global');
const navigate = useNavigate();
  
  useEffect(() => { 
    fetchDashboard();
  }, []);
  console.log(token)

  const fetchDashboard = async () => {
    setLoading(true);
        const response= await axios.get(API+ "Dashboard/GetDashboard",{headers: {'Authorization': 'Bearer '+token}})
        .then((response)=>{
          if(response.data.StatusCode=200){
            for (var i = 0; i < response.data.Result.length; i++){
              if (response.data.Result[i].code =="001")
              {setModelone({heading:response.data.Result[i].headerName,List:response.data.Result[i].dashboardLists}) }
          
              if (response.data.Result[i].code =="002")
              { setModeltwo({heading:response.data.Result[i].headerName,List:response.data.Result[i].dashboardLists})}
              if (response.data.Result[i].code =="003")
             {setModelthree({heading:response.data.Result[i].headerName,List:response.data.Result[i].dashboardLists}) }
          
              if (response.data.Result[i].code =="004")
              {setModelfour({heading:response.data.Result[i].headerName,List:response.data.Result[i].dashboardLists}) }
              if (response.data.Result[i].code =="005")
              {setModelfive({heading:response.data.Result[i].headerName,List:response.data.Result[i].dashboardLists})  }
              if (response.data.Result[i].code =="006")
              { setModelsix({heading:response.data.Result[i].headerName,List:response.data.Result[i].dashboardLists})}
          }
          }
           setLoading(false)
        })
        .catch((err) => {
          debugger;
          localStorage.setItem('err',err.message)
         navigate('/error')
          setLoading(false)
        });
     
    };
    
 const getData = async (id,name) =>{
  localStorage.setItem("id", id);
  localStorage.setItem("name", name);
  navigate('/details');
};
console.log(modelthree.readmore,modelthree.heading)
  return (
    <>
<Navebar></Navebar>
{loading && <Loader></Loader> }
{!loading &&
<>
    <Ticker></Ticker>
   <div className='home'>
   <Grid container className='row'>
  <Grid xs={3} className=' col1 row'>
  <Grid xs={2} container className='card r'>
  {modelone.List && <>
  <List className={readMore1? 'list-group':'list-groupexpand'} sx={{listStyleType:'disc',listStylePosition: 'inside'}}>
<h2>{t("Landing_Page.sec1title")}</h2>
<h3>{modelone.heading}</h3>
{modelone.List.map((name,id) => (     
      <ListItem className="list-group-item" key={id} sx={{ display: 'list-item' }} onClick={event=>getData(modelone.List[id].id,modelone.List[id].name)}>{modelone.List[id].name}</ListItem> ))}
</List>

{modelone.List.length>4 &&
<h4 className="btn readmore" onClick={() => setReadMore1(!readMore1)}>{readMore1 ? "read less.." : "  read more.."}</h4>} </> }
        </Grid>
  </Grid>

 
  <Grid xs={9} className='row col2'  >
  <Grid xs={12} className='heading'><h2>{t("Landing_Page.sec2title")}</h2></Grid>
    <Grid xs={3} className='card list1 '>
    {modeltwo.List && <>
        <List className={readMore2? 'list-group':'list-groupexpand'}  sx={{
item:'true',
listStyleType: 'disc',
listStylePosition: 'inside'}}>

<h3>{modeltwo.heading}</h3>
{modeltwo.List.map((name,id) => (     
      <ListItem className="list-group-item" key={id} sx={{ display: 'list-item' }} onClick={event=>getData(modeltwo.List[id].id,modeltwo.List[id].name)}>{modeltwo.List[id].name}</ListItem>     
       ))}
     
</List>
{modeltwo.List.length>4 &&
<h4 className="btn readmore" onClick={() => setReadMore2(!readMore2)}>
          {readMore2 ? "read less.." : "  read more.."}
        </h4>}
        </> }
    </Grid>
    <Grid xs={3}  className='card'>
    {modelthree.List && <>
        <List className={readMore3? 'list-group':'list-groupexpand'}  sx={{listStyleType: 'disc',
listStylePosition: 'inside'

}}>

<h3>{modelthree.heading}</h3>

{modelthree.List.map((name,id) => (     
      <ListItem className="list-group-item" key={id} sx={{ display: 'list-item' }} onClick={event=>getData(modelthree.List[id].id,modelthree.List[id].name)}>{modelthree.List[id].name}</ListItem> 

       ))} 
</List>
{modelthree.List.length>4 &&
<h4 className="btn readmore" onClick={() => setReadMore3(!readMore3)}>
{readMore3 ? "read less.." : "  read more.."}
        </h4>}</> }
    </Grid>
    <Grid xs={3} className='card training data4'>
    {modelfour.List && <>
      <List className={readMore4? 'list-group':'list-groupexpand'}  sx={{
listStyleType: 'disc',
listStylePosition: 'inside'}}>
<h3>{modelfour.heading}</h3>
{modelfour.List.map((name,id) => (     
      <ListItem className="list-group-item" key={id} sx={{ display: 'list-item' }} onClick={event=>getData(modelfour.List[id].id,modelfour.List[id].name)}>{modelfour.List[id].name}</ListItem>     
       ))}
</List>
{modelfour.List.length>4 &&
<h4 className="btn readmore" onClick={() => setReadMore4(!readMore4)}>
          {readMore4 ? "read less.." : "  read more.."}
        </h4>}</> }
    </Grid>
  </Grid>
  </Grid>
 
  <Box className='row2'>
        <Box className='row2column1'>
        {modelfive.List && <>
          <h3 className='center'>{modelfive.heading}</h3>
          <List className={readMore5? 'list-group':'list-groupexpand'} sx={{
        listStylePosition: 'inside'
      }}>

{modelfive.List.map((name,id) => (     
      <ListItem className="list-group-item" key={id} sx={{ display: 'list-item' }} onClick={event=>getData(modelfive.List[id].id,modelfive.List[id].name)}>{modelfive.List[id].name}</ListItem>     
       ))}
   

  
</List>

{modelfive.List.length>4 &&
<h4 className="btn readmore" onClick={() => setReadMore5(!readMore5)}>
          {readMore5 ? "read less.." : "  read more.."}
        </h4>}  </> }
        </Box>

        <Box className='row2column2'>
        {modelsix.List && <>
          <h3 className='center '>{modelsix.heading}</h3>
          <List className={readMore6? 'list-group':'list-groupexpand'} sx={{listStyleType: 'disc',listStylePosition: 'inside'}}>
          

{modelsix.List.map((name,id) => (     
      <ListItem className="list-group-item" key={id} sx={{ display: 'list-item' }} onClick={event=>getData(modelsix.List[id].id,modelsix.List[id].name)}>{modelsix.List[id].name}</ListItem>     
       ))}
    
 <ListItem className="list-group-item"  sx={{ display: 'list-item' }} >Todays Event</ListItem>
</List>
{modelsix.List.length>4 &&
<h4 className="btn readmore" onClick={() => setReadMore6(!readMore6)}>
          {readMore6 ? "read more.." : "  read less.."}
        </h4>}</>}
        </Box>
      </Box>
      <br></br>
</div>

</>}

<Footer></Footer>
    </>

)


};

