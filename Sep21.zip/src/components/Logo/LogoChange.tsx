import React, { useEffect, useMemo, useState } from 'react'
//import Navebar from '../../Reusable/Navebar/Navebar'
//import AdminSidebar from '../Sidebar/AdminSidebar'
import { GiHamburgerMenu } from 'react-icons/gi'
//import Footer from '../../Reusable/Footer/Footer'
import { Field, Form, Formik } from 'formik'
import {  Grid, MenuItem } from '@mui/material'
import { Select, TextField } from 'formik-material-ui'
import * as yup from 'yup'
import './LogoChange.css'
import Button from '@material-ui/core/Button'
import Card from '@material-ui/core/Card'
import axios from 'axios'
import { profile } from 'console'
import { useTranslation } from 'react-i18next'

const LogoChange = () => {
    const initialValues = useMemo(() => ({
        profile: '',
        logo: ''

    }), [])
    const validate = yup.object().shape({
        profile: yup.mixed().required()
    })
    const[t,i18n]=useTranslation('global');
    const createLogo=async(data)=>{
        const formData=new FormData();
         formData.append("file",data.profile[0]);
         formData.append("fileName",data.logo);
      
        try {
            const res = await axios.post("https://localhost:7032/api/Dashboard/UpdateLogo", formData)
           
        } catch (ex) {
            console.log(ex);
        }
        window.location.reload();
      
             };
    return (
        <>
          
            <Formik
                enableReinitialize={true}
                initialValues={initialValues}
                validationSchema={validate}
                onSubmit={(data) => {
                    createLogo(data)
                }
                }
            >

                {({values,setFieldValue }) => (
                    <Card className='logocard' variant="outlined" > 
                    <Form autoComplete="off" >
                        
                        <Grid className='logo'>

                            <Grid item>
                                <Field name="logo" className="logodropdown" component={Select} label={t("Admin.logo.logolabel")}
                               required >
                                    <MenuItem key='1' value="Cognizant">{t("Admin.logo.logocognizant")}</MenuItem>
                                    <MenuItem key='2' value="Sanofi">{t("Admin.logo.logosanofi")}</MenuItem>
                                </Field>
                            </Grid>

                            <Grid item>
                            <input name="profile" type="file" accept="image/*"
                                    onChange={(event) => {
                                        setFieldValue("profile", event.currentTarget.files);
                                    }} />
                                      
                            </Grid>
                        </Grid>
                      
                        <Grid paddingTop={2}>
                            
                            <Button type="submit" className='logosubmitbutton' variant="contained" color="primary">{t("submit")}</Button>
                        </Grid>
                    </Form>
                                     
                    </Card>
                )}
            </Formik>
         
        </>
    );
};

export default LogoChange
