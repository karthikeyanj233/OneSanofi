import { Button, Grid, MenuItem } from '@material-ui/core';
import { Dialog, DialogContent, DialogTitle } from '@mui/material';
import { Field, Form, Formik } from 'formik';
import { Select, TextField } from 'formik-material-ui';
import {  useEffect, useState } from 'react';
import Country from '../../jsonfiles/Country.json'
import State from '../../jsonfiles/State.json'
import City from '../../jsonfiles/City.json'
import {v4 as uuidv4} from "uuid";
import { editFormValidationSchema,userFormValidationSchema,handlemobile } from '../../Validator';
import { useTranslation } from 'react-i18next';
export default function FormikCreate({ open, onClose, formType, stateValues, cityValues, initialData, onSubmit }) {
 
  const validationSchema = formType === 'user' ? userFormValidationSchema : editFormValidationSchema;
  const [countries] = useState(Country);
  const [states] = useState(State);
  const[t,i18n]=useTranslation('global');
  const [cities] = useState(City);
  const [filteredStates, setFilteredStates] = useState([]) as any;
  const [filteredCities, setFilteredCities] = useState([]) as any ;
  useEffect(()=>{
	setFilteredStates(stateValues)
  setFilteredCities(cityValues)
	},[stateValues])

  const onChangeCountry = (e) => {
    setFilteredStates(states.filter(ctr => ctr.countryName === e.target.value))
    setFilteredCities([])
  };
  
  const onChangeState = (e) => {
    setFilteredCities(cities.filter(ctr => ctr.stateName === e.target.value))
  };

  const [selectedate,setSelectedDate]=useState(null) as any;

const handledate=(e)=>{

  const selected=new Date(e.target.value) ;

  const today= new Date() ;

 

  if(selected<=today){setSelectedDate(selected);}

};

  return (
    <>
        <Formik
          enableReinitialize={true}
          initialValues={initialData}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
        >
         
          {({resetForm,values}) => (
            
            <Form autoComplete="off" >
          
              <Grid container  spacing={2}>
                <Grid item  >
                  <Field name="firstName" required component={TextField} label={t("Admin.form.firstname")} inputProps={{ maxLength:10}} />
                </Grid>

                <Grid item>
                  <Field name="lastName" required component={TextField} label={t("Admin.form.lastname")} inputProps={{ maxLength:10}}/>
                </Grid>
            </Grid>
          <Grid container  spacing={2}>
            { formType === 'user' && (

<>
<Grid item>
<Field name="email" required  type='email' component={TextField} label={t("Admin.userlist.tablehead.email")} />
</Grid>
</>

)}

  { formType === 'edit' && (

<>
<Grid item>
<Field name="email" disabled type='email' component={TextField} label={t("Admin.userlist.tablehead.email")} />
</Grid>
</>

)}

                <Grid item>
                  <Field name="mobile" required component={TextField} label={t("Admin.userlist.tablehead.phone")} onKeyPress={handlemobile}/>
                </Grid>
               </Grid>  
               <Grid container  spacing={2}>
               <Grid item>
                      <Field name="password" required type='password' component={TextField} label={t("Admin.form.password")} />
                    </Grid>  
                    {formType === 'user' && (
                       <>
                    <Grid item>
                      <Field name="confirmPassword" required type='password' component={TextField} label={t("Admin.form.confirmPassword")} />
                    </Grid>
                  </>
                )}
            

                </Grid>
                <Grid container  spacing={2}>
                <Grid item>
                  <Field name="country" required className="dropdown" component={Select} label={t("Admin.userlist.tablehead.country")} onChange={(e) => onChangeCountry(e)} >
                    {
                      countries &&
                      countries.map((option) => (
                        <MenuItem key={option.countryName} value={option.countryName}>
                          {option.countryName}
                        </MenuItem>
                      ))
                    }
                  </Field>

                </Grid>

                <Grid item>
                  <Field name="state" className="dropdown" component={Select} label={t("Admin.form.state")} onChange={(e) => onChangeState(e)} required >
                    {
                      filteredStates &&
                      filteredStates.map((option) => (
                        <MenuItem key={option.stateName} value={option.stateName}>
                          {option.stateName}
                        </MenuItem>
                      ))
                    }
                  </Field>
                </Grid>
                    </Grid>
                    <Grid container  spacing={2}>
                <Grid item>
                  <Field name="city" className="dropdown" component={Select} label={t("Admin.form.city")} required>
                    {
                      filteredCities &&
                      filteredCities.map((option) => (
                        <MenuItem key={uuidv4()} value={option.cityName}>
                          {option.cityName}
                        </MenuItem>
                      ))
                    }
                  </Field>

                </Grid>
                </Grid>
                <Grid container  spacing={2}>
                <Grid item>
                  <Field name="address" required className="dropdown address" component={TextField} rows="2" multiline label={t("Admin.form.address")} />
                </Grid>
                <Grid item>
                <Field name="dob" type="date" fullwidth  label={t("Admin.form.dob")} variant="outlined"  required component={TextField} onChange={handledate} value={selectedate?selectedate.toISOString().slice(0, -14):''}  inputProps={{ maxDate:new Date().toISOString().slice(0, -14),style:{marginTop:'0.9rem'}}} />
                  </Grid>
                </Grid>
                <Grid container spacing={2}>

<Grid item >

<Button type="submit" variant="contained" color="primary">

{t("submit")}

</Button></Grid>

<Grid item>

{formType === 'user'?

<Button type="reset" variant="contained" color="secondary" onClick={()=>{resetForm({values:initialData});}}>{t("reset")}</Button>:<Button type="reset" variant="contained" color="secondary">{t("reset")}</Button> }

</Grid>

</Grid>
            </Form>
          )}
        </Formik>
        </>
  );
}