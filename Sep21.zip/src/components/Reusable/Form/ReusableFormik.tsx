import React, { useEffect, useMemo, useState} from 'react';
import FormikDialog from './FormikDialogue';
import axios from 'axios';
import State from '../../jsonfiles/State.json'
import City from '../../jsonfiles/City.json'
import {API} from "../../../config"

interface Childprops{
    parentFunction:Function
}
const CreateFormik= (props:Childprops) => {
    const form=localStorage.getItem('form')
    const token =localStorage.getItem("Token") as any
    const [openUserForm, setOpenUserForm] = useState(false);
    const [openEditForm, setOpenEditForm] = useState(false);
    const [states] = useState(State);
    const [cities] = useState(City);
    const [filteredStates, setFilteredStates] = useState([]) as any;
    const [filteredCities, setFilteredCities] = useState([]) as any;
    const id=localStorage.getItem('edit_id')
    const[data,setData]=React.useState({
        id:'' ,
        firstName:'',
        lastName:'',
        email:'',
        password:'',
        country:'',
        city:'',
        state:'',
        address:'',
        mobile:''
    })
    const handleOpenUserForm = () => {
        setData({...data,
            id:'',
            firstName:'',
            lastName:'',
            email:'',
            country:'',
            city:'',
            state:'',
            password:'',
            address:'',
            mobile:''
        })
        setOpenUserForm(true);
    };
    const handleCloseUserForm = () => {
        setOpenUserForm(false);
    };
    const handleOpenEditForm = () => {
        setOpenEditForm(true);
        axios.get(API+'User/GetUserById?Id='+id,{headers: {'Authorization': 'Bearer '+token}})
        .then(
          res=>{
            setData({...data,
            id:res.data.Result.id,
            firstName:res.data.Result.firstName,
            lastName:res.data.Result.lastName,
            email:res.data.Result.email,
            country:res.data.Result.country,
            city:res.data.Result.city,
            state:res.data.Result.state,
            password:res.data.Result.password,
            address:res.data.Result.address,
            mobile:res.data.Result.phoneNumber
        })
        setFilteredStates(states.filter(ctr => ctr.countryName === res.data.Result.country ))
        setFilteredCities(cities.filter(ctr => ctr.stateName ===res.data.Result.state))  
        console.log(res.data.Result)
            }
        ) 
        .catch(err=>console.log(err))
    };
    useEffect(() => {   
      openForm()
      }, []);
    const openForm=()=>{
        if(form=='Edit'){
           handleOpenEditForm();
        }
        else{
          //  handleOpenUserForm();
        }
    }
    const handleCloseEditForm = () => {
        setOpenEditForm(false);
    };
    const handleUserFormSubmit = (values) => {
        console.log('User Form Submission:', values);
        axios.post(API+"User/CreateUser", {
          FirstName:values.firstName,
          LastName:values.lastName,
          Email:values.email,
          Password:values.password,
          PhoneNumber:values.mobile,
          Country:values.country,
          State:values.state,
          City:values.city,
          Address:values.address,
         
        },{headers: {'Authorization': 'Bearer '+token}})
          .then((response) => {
            if (response) {
                alert('User Created Successfully');
             console.log(response);
           props.parentFunction()
            }
          })
         .catch((err) => {
            console.log("Err", err);
          });
        
    };
    const handleEditFormSubmit = (values) => {

        // Handle edit form submission here, e.g., send the form data to the API

        console.log('Edit Form Submission:', values);
        axios.post(API+"User/UpdateUser", {
            Id:data.id,
            FirstName:values.firstName,
            LastName:values.lastName,
            Password:values.password,
            Email:values.email,
            Country:values.country,
            State:values.state,
            City:values.city,
            Address:values.address,
            PhoneNumber:values.mobile,
          },{headers: {'Authorization': 'Bearer '+token}})
            .then((response) => {
              if (response) {
                alert('User Updated Successfully');
               console.log(response);
               props.parentFunction()
              }
            })
           .catch((err) => {
              console.log("Err", err);
            });
        handleCloseEditForm();
    };
    const initialValues=useMemo(()=>({
        firstName:data? data.firstName:'',
        lastName:data? data.lastName:'',
        email:data? data.email:'',
        password:data?data.password:'',
        confirmPassword:data?data.password:'',
        country:data?data.country:'',
        state:data?data.state:'',
        city:data?data.city:'',
        address:data?data.address:'',
        mobile:data?data.mobile:''
        }),[data])

      
    return (
        <div>{form =='Create' &&(
            <FormikDialog
                open={openUserForm}
                onClose={handleCloseUserForm}
                formType="user"
                initialData={initialValues}
                onSubmit={handleUserFormSubmit}
                stateValues={filteredStates}
                cityValues={filteredCities}
            />) }
            {form =='Edit' && (
            <FormikDialog
                open={openEditForm}
                onClose={handleCloseEditForm}
                formType="edit"
                initialData={initialValues}
                onSubmit={handleEditFormSubmit}
                stateValues={filteredStates}
                cityValues={filteredCities}
            />)}

        </div>
    );
};
export default CreateFormik