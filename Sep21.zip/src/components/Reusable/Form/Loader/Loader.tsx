import './Loader.css'

function Loader(){
    return <div className="modalsss">
            <div className="loader"></div>
        </div>
}

export default Loader;