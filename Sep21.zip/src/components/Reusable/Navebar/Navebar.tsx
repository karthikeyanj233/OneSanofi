import { Avatar, Divider, IconButton, List, ListItem, ListItemButton, ListItemIcon, Menu, MenuItem, Switch } from '@mui/material';
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import {Element} from 'react-scroll'
import './Navebar.css';
import { Logout, ModeNight } from '@mui/icons-material';
import axios from 'axios';
import { useTranslation } from 'react-i18next';
import {API} from '../../../config';



import france from '../../../images/france.png'

import england from '../../../images/england.png'

import japan from '../../../images/japan.png'

import PopupState, { bindTrigger, bindMenu } from 'material-ui-popup-state';
import { LiaLanguageSolid } from 'react-icons/lia';


// function stringToColor(string: string) {

//   let hash = 0;

//   let i;

//   for (i = 0; i < string.length; i += 1) {
//     hash = string.charCodeAt(i) + ((hash << 5) - hash);
//   }
  

//   let color = '#';

//   for (i = 0; i < 3; i += 1) {

//     const value = (hash >> (i * 8)) & 0xff;

//     color += `00${value.toString(16)}`.slice(-2);

//   }
//   return color;

// }
// function stringAvatar(name: string) {

//   return {

//     sx: {

//       bgcolor: stringToColor(name),

//     },

//     children: `${name.split(' ')[0][0]}${name.split(' ')[1][0]}`,

//   };

// }

const Navebar = () => {
  const navigate=useNavigate();
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const menudata=localStorage.getItem('language')
  const token =localStorage.getItem("Token") as any
  const user=localStorage.getItem("user");

  const[t,i18n]=useTranslation('global');

  const handleChangeLanguage=(lang:string)=>{

      i18n.changeLanguage(lang);

      localStorage.setItem("language",lang)

  }
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const logout=()=>{
    handleClose();
    navigate('/login');
    localStorage.setItem('user','')
  }
  const [cogImage,setCogImage]=useState('') ;
  const [sanofiImage,setSanofiImage]=useState('');

  useEffect(() => {
    axios(API+"Dashboard/GetLogoById?Id=1",{headers: {'Authorization': 'Bearer '+token}}) // Replace with your API endpoint
    .then((data) => {
        
        const imageBase64 = data.data.Result.imageUrl; // Assuming the API response has a field 'imageBase64'
        setCogImage(imageBase64);

    })
    .catch((error) => {
        console.error('Error fetching image data:', error);
    });
}, []);
useEffect(() => {
  axios(API+"Dashboard/GetLogoById?Id=2",{headers: {'Authorization': 'Bearer '+token}}) // Replace with your API endpoint
        .then((data) => {
            
            const imageBase64 = data.data.Result.imageUrl; // Assuming the API response has a field 'imageBase64'
            setSanofiImage(imageBase64);

        })
        .catch((error) => {
            console.error('Error fetching image data:', error);
        });

}, []);
  const navigateToProfile = () => {
    // 👇️ navigate to /contacts
    navigate('/general');
  };;
  return (
    <Element name='navebar'>

    <div className='navebar row muiAppBar'>

<img className='cognizant'  src={cogImage}></img>



       <h1 onClick={()=>navigate('/')}>{t("navebar.navebar_title")}</h1>

        <img className='sanofi' src={sanofiImage}></img>

        <PopupState variant="popover" popupId="demo-popup-menu">

  {(popupState) => (

    <React.Fragment>

      <p className='language'  {...bindTrigger(popupState)}>{menudata}<LiaLanguageSolid  ></LiaLanguageSolid></p>

     

      <Menu {...bindMenu(popupState)} className='languagemenu'>

        <MenuItem className={menudata=='en' ?'active_lang':'lang'} onClick={popupState.close} ><p onClick={()=>handleChangeLanguage('en')}><img className='lang_img'  src={england}></img>En</p></MenuItem>

        <MenuItem className={menudata=='jp' ?'active_lang':'lang'} onClick={popupState.close} ><p onClick={()=>handleChangeLanguage('jp')}><img className='lang_img' src={japan}></img>Jp</p></MenuItem>

        <MenuItem className={menudata=='fr' ?'active_lang':'lang'} onClick={popupState.close} ><p onClick={()=>handleChangeLanguage('fr')}><img className='lang_img' src={france}></img>Fr</p></MenuItem>

      </Menu>

    </React.Fragment>

  )}

</PopupState>



<div className='account'>

<h4>{user}</h4>

<IconButton

size="large"

aria-label="account of current user"

aria-controls="menu-appbar"

aria-haspopup="true"

onClick={handleClick}

className='usericon'

color="inherit"

>

<Avatar></Avatar>

</IconButton>

<Menu

    className='dropdown'

    anchorEl={anchorEl}



    id="account-menu"



    open={open}

    onClose={handleClose}

    onClick={handleClose}



    PaperProps={{



      elevation: 0,



      sx: {

        overflow: 'visible',

        filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',

        mt: 1.5,

        '& .MuiAvatar-root': {

          width: 32,

          height: 32,

          ml: -0.5,

          mr: 1,

        },



        '&:before': {

          content: '""',

          display: 'block',

          position: 'absolute',

          top: 0,

          right: 14,

          width: 10,

          height: 10,

          bgcolor: 'background.paper',

          transform: 'translateY(-50%) rotate(45deg)',

          zIndex: 0,



        },



      },



    }}



    transformOrigin={{ horizontal: 'right', vertical: 'top' }}

    anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}



  >



    <MenuItem  className='menuitem'onClick={navigateToProfile}>

      <Avatar /> {t("navebar.admin")}

    </MenuItem>

    <Divider />

    <MenuItem className='menuitem' onClick={()=>{logout()}}>

      <ListItemIcon >

        <Logout fontSize="small" />

      </ListItemIcon >



      {t("navebar.logout")}



    </MenuItem>



  </Menu>



</div>



    </div>



    </Element>



      )}
export default Navebar
