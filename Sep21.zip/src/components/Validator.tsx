
import * as yup from 'yup'

export const emailValidator=(emailid)=>{
    const emailValid= /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    return emailValid.test(emailid)
}

export const passwordValidator=(password)=>{
    const passwordValid= /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/;
    return passwordValid.test(password)
}
export const phoneValidator=(phone)=>{
    const phoneValid= /^\d{10}$/;
    return phoneValid.test(phone)
}
export const confirmPassword=(confirmPassword,password)=>{




    let password_match=false;

    if(confirmPassword===password){

        password_match=true;

    }

    return password_match;

}
export const mobileValidator=(mobile)=>{

    const phoneValid= /^\d{10}$/;

    return phoneValid.test(mobile)


}
export const nameValidator=(name)=>{

    const userValid=/^[A-Za-z]+$/;

    return userValid.test(name);

}

export const userFormValidationSchema = yup.object().shape({
    firstname:yup.string().min(3,'*Enter alteast 3 charcaters.'),
    lastname:yup.string().min(3,'*Enter alteast 3 charcaters.'),
    email: yup.string().email('Enter valid email'),
    password: yup.string().min(8, '*password must contain 8 or more characters with at least one of each: uppercase, lowercase, number and special character')
    .matches(/[0-9]/, '*Password requires a number')
    .matches(/[a-z]/, '*Password requires a lowercase letter')
    .matches(/[A-Z]/, '*Password requires an uppercase letter')
    .matches(/[^\w]/, '*Password requires a symbol'),
    confirmPassword: yup.string().oneOf([yup.ref("password")], 'Password does not match'),
    mobile:yup.string().required('*Mobile Number is required')
    .matches(/^[6-9]\d{9}$/,'*Enter valid number'),
  })
 export  const editFormValidationSchema = yup.object().shape({
    email: yup.string().email('Enter valid email'),
  })

export const handlemobile=(e)=>{
if(e.target.value.length>10){ e.preventDefault();}
if(isNaN(Number(e.key))){e.preventDefault();}

  }

 