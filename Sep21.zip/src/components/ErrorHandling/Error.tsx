import React from 'react'

const Error = () => {
    const err=localStorage.getItem('err')
  return (
    <div style={{textAlign:'center',marginTop:100}}>
        <p >Somenthig went wrong ...</p>

       <p>{err}</p>
    </div>
  )
}

export default Error
