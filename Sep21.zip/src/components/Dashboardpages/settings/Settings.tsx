import React from 'react'

const Settings = () => {
  return (
    <div className='darktheme'>
      settings
    </div>
  )
}

export default Settings
