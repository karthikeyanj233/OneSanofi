import { Button, MenuItem, TextField } from '@material-ui/core';
import axios from 'axios';
import JoditEditor from 'jodit-react';
import React, { useRef } from 'react'
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import {API} from '../../../config'
import './Contentedit.css'
import { useTranslation } from 'react-i18next';
const Dropdown = () => {
    const editor = useRef(null);
    const [content, setContent] = React.useState('');
    const [dashboardBox, setDashboardBox] = React.useState([]) as any
    const [dashboardBoxValue, setDashboardBoxValue] = React.useState() as any
    const [dashboardValue, setDashboardValue] = React.useState() as any
    const [Dashboard, setDashboard] = React.useState([{ id: '', dashboardSubName:""}]) as any
    const [DashboardDetails, setDashboardDetails] = React.useState([]) as any
    const [idValue, setIdValue] = React.useState() as any
    const [dashboardHeaderError, setDashboardHeaderError] = React.useState("")
    const [dashboardError, setDashboardError] = React.useState("")
    const token =localStorage.getItem("Token") as any
    const[t,i18n]=useTranslation('global');
    React.useEffect(() => {
        axios.get(API+'Dashboard/GetDashboard',{headers: {'Authorization': 'Bearer '+token}})
            .then(
                res => {
                    setDashboardBox(res.data.Result);
                }
            )
            .catch(err => console.log(err))
    }, [])

    const changeDashboardBox = (e) => {
        setDashboardBoxValue(e.target.value);
        setDashboard(dashboardBox.find(ctr => ctr.headerName === e.target.value)?.dashboardLists)
    }


    const changeDashboard = (e) => {
        setDashboardValue(e.target.value)
        setIdValue(Dashboard.find(ctr => ctr.name === e.target.value)?.id)
        handleGetDashboardDetails(e)
    }

    const handleGetDashboardDetails = (id) => {
        const res = axios.get(API+'Dashboard/GetDashboardDetailsById?Id='+ id,{headers: {'Authorization': 'Bearer '+token}})
            .then( res => { setDashboardDetails(res.data.Result);} )
            .catch(err => console.log(err))
    }

    const updateUser=(e)=>{
        e.preventDefault();
        const response =axios.post(API+"Dashboard/UpdateDashboardDetails",{
            Id:DashboardDetails.id,
            Dashboard_Html:content,
            Dashboard_Id:DashboardDetails.dashboard_Id,
            Description:DashboardDetails.description,
            Code:DashboardDetails.code
        },{headers: {'Authorization': 'Bearer '+token}})

        .then((response) => {
               if(response.status==200){
                alert('content updated Successfully');
               };
        })

        .catch((err) => {
          console.log("Err", err);
        });
    }

    const handleSubmit=(e)=>{ let count=0
        if (!dashboardBoxValue || !dashboardBoxValue.length) {
            setDashboardHeaderError("This field is required");
            count=count+1
          }
        else { setDashboardHeaderError(""); }
        if (!dashboardValue || !dashboardValue.length) {
            setDashboardError(" This field is required");
            count=count+1
          }
        else { setDashboardError(""); }
        if(count==0)
        {updateUser(e)
        }
    }

    return (

        <div>
            <br></br>
            <br></br>
            <br></br>
            <div className='row' style={{justifyContent:'flex-start'}}>
                <TextField
                style={{backgroundColor:'white',padding:5,color:"green" }}
                    error={dashboardHeaderError && dashboardHeaderError.length ? true : false}
                    helperText={dashboardHeaderError}
                    required
                    className='dropdown'
                    id="dashboardBox"
                    select
                    label={t("Admin.content_edit.dashboarheader")}
                    variant='outlined'
                    name="country"
                    onChange={changeDashboardBox}{...changeDashboard} >

                    {dashboardBox.map((option) => (
                        <MenuItem key={option.headerName} value={option.headerName}>
                            {option.headerName}
                        </MenuItem>
                    ))}
                </TextField>


                <TextField
                    style={{marginLeft:100,backgroundColor:'white',padding:5}}
                    error={dashboardError && dashboardError.length ? true : false}
                    helperText={dashboardError}
                    required
                    className='dropdown'
                    id="dashboard"
                    select
                    label={t("Admin.content_edit.dashboard")}
                    variant='outlined'
                    name="dashbpard"
                    onChange={changeDashboard}>

                    {Dashboard.map((option) => (
                        <MenuItem key={option.name} value={option.name} onClick={() => handleGetDashboardDetails(option.id)}>
                            {option.name}
                        </MenuItem>
                    ))}

                </TextField>
            </div>
            <br></br>
            <br></br>

            <JoditEditor
              className='editor'
                ref={editor}
                value={DashboardDetails.dashboard_Html}
                onChange={newContent => setContent(newContent)}
                />
            <Button style={{marginLeft:500,marginTop:50}} type="submit" color="primary" variant="contained" onClick={handleSubmit}>{t("submit")}</Button>
        </div>
    )
}

export default Dropdown