import React from 'react'
import UserList from './UserList'
import './Onboarding.css'
import { useTranslation } from 'react-i18next';

const Onbording = () => {
  const[t,i18n]=useTranslation('global');

  return (
    <>
    <div className='onboarding'>
      <h1 className='onboarding_heading'>{t("Admin.onboarding.onbording_text")}</h1>
     <UserList></UserList>
    </div>
    </>
  )

}

export default Onbording
