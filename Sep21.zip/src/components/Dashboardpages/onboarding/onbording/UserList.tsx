import { useState, useEffect, useMemo } from 'react';
import './UserList.css'
import { Table, TableHead, TableRow, TableBody, Button, styled} from '@mui/material'
import axios from 'axios';
import Pagination from '../../onboarding/onbording/Pagination';
import { Dialog, DialogActions, DialogContent, DialogContentText, TextField } from '@material-ui/core';
import { AiFillCloseCircle}from "react-icons/ai";
import {API} from '../../../../config'
import Loader from '../../../Reusable/Form/Loader/Loader';
import { FaSearch } from "react-icons/fa";
import ReusableFormik from '../../../Reusable/Form/ReusableFormik';
import { useTranslation } from 'react-i18next';
const StyledTable = styled(Table)`
    width: 90%;
    margin: 50px 0 0 50px;
`;

const TRow = styled(TableRow)`
    & > td{
        font-size: 14px
    }
`;
let PageSize = 5;
const UserList = () => {
    const [users, setUsers] = useState([
        {
            id:'',
            firstName:'',
             email:'',
            phoneNumber:'',
            age:'',
            gender:'',
            country:''
        }
    ]);
    const[t,i18n]=useTranslation('global');
    const[deleteId,setDeleteid]=useState(Number) 
    const form=localStorage.getItem('form')
    const [open, setOpen] =useState(Boolean);
    const [search,setSearch]=useState('');
    const[loading,setLoading]=useState(true)
    const token =localStorage.getItem("Token") as any
  const handleClickToOpen = () => {
    setOpen(true);
};

const handleToClose = () => {
  setOpen(false);
};

    const getAllUsers = async () => {
      const response = await axios.get(API+
        "User/GetAllUser",{headers: {'Authorization': 'Bearer '+token}} ).then((response)=>{
          if (response.data.StatusCode=200) {
              const General = response.data.Result;
              return  setUsers(General);
         }

        }) .catch((err) => {
          localStorage.setItem('err',err.message)
          console.log(err)
      
        });;
        setLoading(false)
           };
    
    const deleteUser=async ()=>{
   setOpens(false)
        {
            const response= await axios.delete(API+ "User/DeleteUser?Id="+deleteId,{headers: {'Authorization': 'Bearer '+token}})
                .then((response) => {
                    if (response.data.StatusCode=200) {
                         alert("User Deleted Successfully")  }
                  })
                  .catch((err) => {
                    console.log("Err", err);
                  });
                }}
            
      useEffect(() => { 
       getAllUsers()
      }, []);
       
      const getData = async (id) =>{
        handleClickToOpen()
        localStorage.setItem("edit_id", id);
        localStorage.setItem('form','Edit')
      };


  const [currentPage, setCurrentPage] = useState(1);
  const currentTableData = useMemo(() => {
    const firstPageIndex = (currentPage - 1) * PageSize;
    const lastPageIndex = firstPageIndex + PageSize;
    return users.slice(firstPageIndex, lastPageIndex);
  }, [currentPage,getAllUsers()]);


  const editForm=()=>{
    handleToClose()
  }
  const [opens, setOpens] = useState(false);

  const handleClose = (id) => {
    setOpens(true);
setDeleteid(id)
  };
  const openForm=()=>{
    handleClickToOpen()
    localStorage.setItem("form",'Create')
   }
  
    return (
<>
{loading && <Loader/> }


{!loading && <>
  <div className="input-wrapper">
      <FaSearch id="search-icon" />
      <input
      className='input'
        placeholder={t("Admin.userlist.search")}
        required
        id="Search"
        onChange={(e)=>setSearch(e.target.value)}
      />
    </div>

    <Button  color="primary"  variant="contained" className='addbutton' onClick={()=>{openForm()}}>{t("Admin.userlist.adduser")}</Button>

        <StyledTable className='userlist'>
            <TableHead>
              
                <td><b>{t("Admin.userlist.tablehead.s.no")}</b></td>
                    <td><b>{t("Admin.userlist.tablehead.name")}</b></td>
                    <td><b>{t("Admin.userlist.tablehead.email")}</b></td>
                    <td><b>{t("Admin.userlist.tablehead.phone")}</b></td>
                    <td><b>{t("Admin.userlist.tablehead.country")}</b></td>
                    <td><b>{t("Admin.userlist.tablehead.edit")}</b></td>
                    <td><b>{t("Admin.userlist.tablehead.remove")}</b></td>
              
            </TableHead>
            <TableBody className='leftspace'> 
                {currentTableData.filter((item)=>{

return search.toLowerCase()===''?item:item.firstName.toLowerCase().includes(search)

}).map((item,key) => (
                    <TRow key={key} className='td'>
                        <td >{key+1+(PageSize*(currentPage-1))}</td>                     
                        <td>{item.firstName}</td>
                        <td>{item.email}</td>
                        <td>{item.phoneNumber}</td>
                        <td>{item.country}</td>
                        <td>
                            <Button color="primary" variant="contained"  onClick={event=>getData(item.id)}>{t("Admin.userlist.tablehead.edit")}</Button>
                            </td><td>
                            <Button color="secondary" variant="contained" onClick={()=>{handleClose(item.id)}} >{t("Admin.userlist.tablehead.remove")}</Button>
                        </td>
                    </TRow>
                ))}

            </TableBody>
            <Dialog open={open}  >
            <div className='dialogutitle'>
           <h2 className='add'>{form}</h2>
           <h3 className='closes' onClick={handleToClose}><AiFillCloseCircle></AiFillCloseCircle></h3>
           </div>

        <DialogContent>
         <ReusableFormik parentFunction={handleToClose}></ReusableFormik>
</DialogContent>
</Dialog>
<Dialog
        open={opens}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
>
<DialogContent>
<DialogContentText id="alert-dialog-description">
{t("Admin.userlist.confirm")}  
</DialogContentText>
</DialogContent>
<DialogActions>
<Button onClick={()=>setOpens(false)}>{t("Admin.userlist.no")} </Button>
<Button onClick={()=>deleteUser()} autoFocus>
{t("Admin.userlist.yes")} 
</Button>
</DialogActions>
</Dialog>
        </StyledTable> </>}
         <Pagination
         className="pagination-bar"
         currentPage={currentPage}
         totalCount={users.length}
         pageSize={PageSize}
         onPageChange={page => setCurrentPage(page)}
       />   
</>
    )}
export default UserList;