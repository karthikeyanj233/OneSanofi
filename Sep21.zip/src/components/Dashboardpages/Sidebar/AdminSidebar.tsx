import {useEffect, useState } from 'react';
import {AiOutlineUserAdd,AiFillHome}from "react-icons/ai";
import {GiHamburgerMenu}from "react-icons/gi";
import {AiFillEdit}from "react-icons/ai";
import {LiaLanguageSolid}from "react-icons/lia";
import Onbording from '../onboarding/onbording/Onbording';
import Home from '../home/Home';
import { RxColorWheel} from "react-icons/rx";
import './AdminSidebar.css'
import {Divider, ListItem, ListItemIcon} from '@material-ui/core';
import Content_edit from '../contentedit/Content_edit';
import Navebar from '../../Reusable/Navebar/Navebar';
import '../../Reusable/Navebar/Navebar.css';
import {TbReplace} from "react-icons/tb"
//import Footer from '../../Reusable/Footer/Footer';
import { List, ListItemButton, Switch } from '@mui/material';
import { ModeNight } from '@mui/icons-material';
//import Language from '../../tralslation';
import Theme from '../theme/Theme';
import LogoChange from '../../Logo/LogoChange';
import Footer from '../../Reusable/Footer/Footer';
import { useTranslation } from 'react-i18next';

const AdminSidebar = ({mode,setMode}) => {
    const[isOpen ,setIsOpen] = useState(false);
    const[subopen,setSubopen]=useState(false);

    const [menudata, setMenudata] = useState("onbording");

    const[t,i18n]=useTranslation('global');
 
   
    const toggle = () => setIsOpen (!isOpen);
    const subopentoggle=()=>setSubopen(!subopen)

    useEffect(() => {   
        setMenudata("")
      }, []);
     

    return (
      <>

        <div className='G_navebar '>
        <div className="top_section">
        <div  className="bars">
       <GiHamburgerMenu onClick={toggle}/>
       </div>
      <Navebar></Navebar>
      </div>
      </div>
      <div className="container">

<div style={{width: isOpen ? "220px" : "70px" }} className="sidebar">

   <div className='liItems'>

   <div className={menudata=='' ?'active spage':'spage'} onClick={()=>setMenudata('')}>

     <div className="icon"><AiFillHome/></div>

     <span id='tooltip'>{t("Admin.sidebar.home")}</span>

    <div  style={{display: isOpen ? "block" : "none"}}  className="link_text">{t("Admin.sidebar.home")}</div>

    </div>

     <div className={menudata=='onboarding' ?'active spage':'spage'}  onClick={()=>setMenudata('onboarding')}>

     <div className="icon"><AiOutlineUserAdd/></div>

     <span id='tooltip'>{t("Admin.sidebar.onboarding")}</span>

    <div style={{display: isOpen ? "block" : "none"}} className="link_text">{t("Admin.sidebar.onboarding")}</div>

    </div>

    <div className={menudata=='content_edit' ?'active spage':'spage'}  onClick={()=>setMenudata('content_edit')}>

     <div className="icon"><AiFillEdit/></div>

     <span id='tooltip'>{t("Admin.sidebar.contentedit")}</span>

    <div style={{display: isOpen ? "block" : "none"}}  className='link_text'>{t("Admin.sidebar.contentedit")}</div>

    </div>

    <div className={menudata=='changeLogo' ?'active spage':'spage'}  onClick={()=>setMenudata('changeLogo')}>

<div className="icon"><TbReplace/></div>

<span id='tooltip'>{t("Admin.sidebar.logo")}</span>

<div style={{display: isOpen ? "block" : "none"}}  className='link_text'>{t("Admin.sidebar.logo")}</div>

</div>

    <div className={menudata=='theme' ?'active spage':'spage'}  onClick={()=>setMenudata('theme')}>

    <div className="icon" onClick={subopentoggle}><RxColorWheel/>

  

    <ul className={subopen ? "open icon":"close "}>

     <li className='color'  onClick={e=>setMode(mode === "white"|| "dark")}><li><button className="buttonC1" title='Dark'  /></li><li className='colortext' style={{display: isOpen ? "block " : "none"}} >Dark</li></li>

     <li className='color' onClick={e=>setMode(mode === "white"||"blue")}><li><button className="buttonC2" title='Light'  /></li><li className='colortext' style={{display: isOpen ? "block" : "none"}} >Blue</li></li>

     <li className='color'  onClick={e=>setMode(mode === "white"|| "green")}><li><button className="buttonC4" title='Green'/></li><li className='colortext' style={{display: isOpen ? "block" : "none"}} >Green</li></li>

     <li className='color' onClick={e=>setMode(mode === "white"||"yellow")}><li><button  className="buttonC6" title='yellow' /></li><li className='colortext' style={{display: isOpen ? "block" : "none"}} >Yellow</li></li>

     <li className='color' onClick={e=>setMode(mode === "white"||"orange")}><li><button  className="buttonC7" title='Red' /></li><li className='colortext' style={{display: isOpen ? "block" : "none"}} >Orange</li></li>

     <li className='color' onClick={e=>setMode(mode === "white"||"purple")}><li><button  className="buttonC8" title='Red' /></li><li className='colortext' style={{display: isOpen ? "block" : "none"}} >Purple</li></li>

     <li className='color' onClick={e=>setMode(mode === "white"||"pink")}><li><button  className="buttonC9" title='pink' /></li><li className='colortext' style={{display: isOpen ? "block" : "none"}} >Pink</li></li>

    </ul>

    </div>

    <span id='tooltip'>{t("Admin.sidebar.theming")}</span>

    <div style={{display: isOpen ? "block" : "none"}}  className='link_text'onClick={subopentoggle}>{t("Admin.sidebar.theming")}</div>
     
    <Divider></Divider>
 
    </div>

    <Divider/>

   </div>

  

</div>
           <main>
           {menudata=="onboarding" && <Onbording></Onbording>}
           {menudata=="" && <Home></Home>}
          {menudata=="content_edit" && <Content_edit></Content_edit>}
          {/* {menudata=="lang" && <Language></Language>} */}
          {menudata=="changeLogo" && <LogoChange></LogoChange>}
          {/* {menudata=="theme" && <Theme setMode={setMode} mode={mode}></Theme> } */}
           </main>
           </div>

           <Footer></Footer>
        </>
    );
};

export default AdminSidebar;