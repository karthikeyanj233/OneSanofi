import { useTranslation } from "react-i18next";

const Home = () => {
  const[t,i18n]=useTranslation('global');
  return (
     
    <div>
   <h2>{t("Admin.home.home_text")}</h2>
    </div>
  )
}

export default Home
