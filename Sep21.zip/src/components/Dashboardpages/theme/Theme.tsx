import './Theme.css'

const Theme = ({mode,setMode}) => {

  return (

    <>
     <h3 className="h3">Select Theme..</h3>
    </>

  )

}

 

export default Theme