import React, { useEffect, useState } from 'react'
import Navebar from '../Reusable/Navebar/Navebar'
import Footer from '../Reusable/Footer/Footer'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Paper } from '@material-ui/core';
import {API} from '../../config'
import './Details.css'
import { BsFillArrowLeftCircleFill } from 'react-icons/bs';
const Details = () => {
  const token =localStorage.getItem("Token") as any
    const id = localStorage.getItem("id");
    const details = localStorage.getItem("name");
    const [para,setPara]=useState() as any;
    const navigate=useNavigate();
   
      useEffect(() => { 
       getData(id);
      }, []);

      const getData = async (id) =>{
        const {data}= await axios.get(API+"Dashboard/GetDashboardDetailsById?Id="+id,{headers: {'Authorization': 'Bearer '+token}});
        const General = data.Result.dashboard_Html;
        setPara(General);
      
      };

  return (
    <>
    
   
      <Navebar></Navebar>
      <div className='BGcolordetails'>
     <BsFillArrowLeftCircleFill style={{fontSize:30, marginLeft:50,marginTop:20,cursor:'pointer'}} onClick={()=>navigate('/')}></BsFillArrowLeftCircleFill>
      <div className='details' >
        <br></br>
        <h2 className='detailscontent'>{details}</h2>
        <br></br>
      <div 
      dangerouslySetInnerHTML={{__html: para}}
    />
      
      </div>
      <br></br>
    </div>
      <Footer></Footer>
      </>
  )
}

export default Details
