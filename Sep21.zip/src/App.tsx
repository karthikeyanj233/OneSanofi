import './App.css';
import { Routes ,Route, BrowserRouter} from 'react-router-dom';      
import Home from "./components/Landingpage/Home";
import Login from './components/Login';
import Moveup from './components/Reusable/Moveup/Moveup';
import Details from './components/DetailsPage/Details';
import AdminSidebar from './components/Dashboardpages/Sidebar/AdminSidebar';
import Error from './components/ErrorHandling/Error'
import { useEffect } from 'react';
import axios from 'axios';
import {API} from './config'
import { useState } from "react";
import Navebar from './components/Reusable/Navebar/Navebar';

var token=localStorage.getItem("Token")

function App() {

  const [mode, setMode] = useState("light") as any;

const checkToken=async ()=>{
  const response= await axios.post(API+"Login/refresh-token",
  {headers: {'Authorization': 'Bearer '+token},
  accessToken:token
})
  .then((response)=>{
  if(response.data.StatusCode==200){
    localStorage.setItem('Token',response.data.Result.accessToken)
  }
  })
  .catch((err) => {
    console.log("refresh token error",err)
  });
}

const MINUTE_MS = 60*4*1000;

useEffect(() => {
  const interval = setInterval(() => {
    checkToken()
   
    
  }, MINUTE_MS);


  return () => clearInterval(interval); 
}, [])

useEffect(() => {
  
  localStorage.setItem("language","en")


}, [])
  return (
    <>
    <div className={mode}>
<BrowserRouter>
  <Routes>
  <Route path="/navebar" element={<Navebar></Navebar>}/>
    <Route path="/" element={<Home></Home>}/>
    <Route path='/details' element={<Details></Details>}/>
    <Route path='login/*' element={<Login></Login>}/>
    <Route path='/general' element={<AdminSidebar setMode={setMode} mode={mode}></AdminSidebar>}/>
    <Route path='/error' element={<Error></Error>}/>
  </Routes>
  <Moveup></Moveup>
  </BrowserRouter>
  </div>
    </>
  );
}

export default App;
