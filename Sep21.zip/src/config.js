
export const API='https://localhost:7032/api/';